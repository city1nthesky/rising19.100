window.onload = function(){
    document.getElementById('url').innerText = location.search.substr(1);
}